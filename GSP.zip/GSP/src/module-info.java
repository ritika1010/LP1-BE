module goalstackplanning {
}